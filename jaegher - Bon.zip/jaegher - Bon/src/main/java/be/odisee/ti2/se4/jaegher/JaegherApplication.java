package be.odisee.ti2.se4.jaegher;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JaegherApplication {

    public static void main(String[] args) {
        SpringApplication.run(JaegherApplication.class, args);
    }

}
